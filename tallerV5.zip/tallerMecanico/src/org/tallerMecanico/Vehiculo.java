
package org.tallerMecanico;

public class Vehiculo {
    private String clienteV;
    private int IdVcar;
    private String matriculaCar;
    private String marcaCar;
    private String modeloCar;
    private String fecha;

    public String getClienteV() {
        return clienteV;
    }

    public void setClienteV(String clienteV) {
        this.clienteV = clienteV;
    }

    public int getIdVcar() {
        return IdVcar;
    }

    public void setIdVcar(int IdVcar) {
        this.IdVcar = IdVcar;
    }

    public String getMatriculaCar() {
        return matriculaCar;
    }

    public void setMatriculaCar(String matriculaCar) {
        this.matriculaCar = matriculaCar;
    }

    public String getMarcaCar() {
        return marcaCar;
    }

    public void setMarcaCar(String marcaCar) {
        this.marcaCar = marcaCar;
    }
    
    public String getModeloCar() {
        return modeloCar;
    }

    public void setModeloCar(String modeloCar) {
        this.modeloCar = modeloCar;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
}
