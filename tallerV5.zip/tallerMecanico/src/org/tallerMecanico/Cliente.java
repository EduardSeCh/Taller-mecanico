
package org.tallerMecanico;

import java.util.ArrayList;



public class Cliente {
    private ArrayList<Cliente> listCliente;
    private int IDUsuario;
    private int IDcliente;
    private String nombreCliente;
    private String ApCleinte;
    private String AmCliente;
    
    public Cliente(){
        listCliente = new ArrayList<>();
    }

    public int getIDUsuario() {
        return IDUsuario;
    }

    public void setIDUsuario(int IDUsuario) {
        this.IDUsuario = IDUsuario;
    }

    public int getIDcliente() {
        return IDcliente;
    }

    public void setIDcliente(int IDcliente) {
        this.IDcliente = IDcliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getApCleinte() {
        return ApCleinte;
    }

    public void setApCleinte(String ApCleinte) {
        this.ApCleinte = ApCleinte;
    }

    public String getAmCliente() {
        return AmCliente;
    }

    public void setAmCliente(String AmCliente) {
        this.AmCliente = AmCliente;
    }
    
    
}
