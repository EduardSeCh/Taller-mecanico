
package org.tallerMecanico;
//import java.io.IOException;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static org.tallerMecanico.AccesoDatos.*;
public class Main extends javax.swing.JFrame {

    Usuario us;
    Cliente cli;
    Vehiculo car;
    int contadorUs;
    int contadorCli;
    int contadorCar;
    public Main() {
        //Pantalla
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        int height = pantalla.height;
        int width = pantalla.width;
        setSize(width/2,height/2);
        setLocationRelativeTo(null);
        
        initComponents();
        //Usuario root
        us = new Usuario();
        us.setId_us(1);
        us.setNombre("Admin");
        us.setAp("UNKNOWN");
        us.setAm("UNKNOWN");
        us.setDirec("UNKNOWN");
        us.setPerfil("Admin");
        us.setNombreUs("root");
        us.setTelefono(123456789);
        us.setPassword("123");
        contadorUs=us.getId_us()+1;
        contadorCli = 1;
        contadorCar = 1;
        BuscarRoot(us);
        leerArchivo(us);
        //poner name usuarios en comobox Cli
        for (int i = 0; i < SacarNameUs().size(); i++) {
            cbCli.addItem(String.valueOf(SacarNameUs().get(i)));
            
        }
        //Colocar name cli en combobox car
        for (int i = 0; i < SacarNameCli().size(); i++) {
            cbClienteCar.addItem(String.valueOf(SacarNameCli().get(i)));
            
        }
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelUsuario), false);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelCl),false);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelVe),false);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelRep),false);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelPiezas),false);
    }
    //Paneles
    public void HabilitarPaneles(){
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelUsuario), true);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelCl),true);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelVe),true);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelRep),true);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelPiezas),true);
    }
    public void DesabilitarPaneles(){
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelUsuario), false);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelCl),false);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelVe),false);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelRep),false);
        PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelPiezas),false);
    }
    
    //Textos us
    public void HabilitartxtUs(){
        txtID_us.setEnabled(true);
        txtNombre_us.setEnabled(true);
        txtAP_us.setEnabled(true);
        txtAM_us.setEnabled(true);
        txtDireccion_us.setEnabled(true);
        cbPerfil_us.setEnabled(true);
        txtNombreUS_us.setEnabled(true);
        txtTelefono_us.setEnabled(true);
        txtPassword_us.setEnabled(true);
    }   
    public void DeshabilitartxtUs(){
        txtID_us.setEnabled(false);
        txtNombre_us.setEnabled(false);
        txtAP_us.setEnabled(false);
        txtAM_us.setEnabled(false);
        txtDireccion_us.setEnabled(false);
        cbPerfil_us.setEnabled(false);
        txtNombreUS_us.setEnabled(false);
        txtTelefono_us.setEnabled(false);
        txtPassword_us.setEnabled(false);
    }
    //Btn Us
    public void DeshabilitarBtnUs(){
        btnSalvar_us.setEnabled(false);
        btnCancelar_us.setEnabled(false);
        btnEditar_us.setEnabled(false);
        btnRemover_us.setEnabled(false);
    }
    public void HabilitarBtnUs(){
        btnSalvar_us.setEnabled(true);
        btnCancelar_us.setEnabled(true);
        btnEditar_us.setEnabled(true);
        btnRemover_us.setEnabled(true);
    }
    //Resetear us
    public void ResetTxtUs(){
        txtID_us.setText("");
        txtBuscar_us.setText("");
        txtNombre_us.setText("");
        txtAP_us.setText("");
        txtAM_us.setText("");
        txtDireccion_us.setText("");
        cbPerfil_us.setSelectedIndex(0);
        txtNombreUS_us.setText("");
        txtTelefono_us.setText("");
        txtPassword_us.setText("");
    }
    
    //Textos Cli
    public void HabilitartxtCli(){
        txtIDCli.setEnabled(true);
        txtNombreCLi.setEnabled(true);
        txtAMCli.setEnabled(true);
        txtAPCli.setEnabled(true);
        cbCli.setEnabled(true);
    }
    public void DesablilitartxtCli(){
        txtIDCli.setEnabled(false);
        txtNombreCLi.setEnabled(false);
        txtAMCli.setEnabled(false);
        txtAPCli.setEnabled(false);
        cbCli.setEnabled(false);
    }
    //Btn cli
    public void HabilitarBtnCli(){
        btnNuevoCLi.setEnabled(true);
        btnSalvarCli.setEnabled(true);
        btnCancelarCLi.setEnabled(true);
        btnEditarCli.setEnabled(true);
        btnRemoverCLi.setEnabled(true);
    }
    public void DesabilitarBtnCli(){
        btnSalvarCli.setEnabled(false);
        btnCancelarCLi.setEnabled(false);
        btnEditarCli.setEnabled(false);
        btnRemoverCLi.setEnabled(false);
    }
    //Resetear cli
    public void ResetCli(){
        txtIDCli.setText("");
        txtNombreCLi.setText("");
        txtAMCli.setText("");
        txtAPCli.setText("");
        cbCli.setSelectedIndex(0);
    }
    //Autos
    //Textos car
    public void HabilitartxtCar(){
        cbClienteCar.setEnabled(true);
        txtIDCar.setEnabled(true);
        txtMatriculaCar.setEnabled(true);
        txtMarcaCar.setEnabled(true);
        txtModeloCar.setEnabled(true);
        txtFechaCar.setEnabled(true);
    }
    public void DesabilitartxtCar(){
        cbClienteCar.setEnabled(false);
        txtIDCar.setEnabled(false);
        txtMatriculaCar.setEnabled(false);
        txtMarcaCar.setEnabled(false);
        txtModeloCar.setEnabled(false);
        txtFechaCar.setEnabled(false);
    }
    //Btn car
    public void HabilitarbtnCar(){
        btnSalvarCar.setEnabled(true);
        btnCancelarCar.setEnabled(true);
        btnEditarCar.setEnabled(true);
        btnRemoverCar.setEnabled(true);
    }
    public void DesabilitarbtnCar(){
        btnSalvarCar.setEnabled(false);
        btnCancelarCar.setEnabled(false);
        btnEditarCar.setEnabled(false);
        btnRemoverCar.setEnabled(false);
    }
    //Reset car
    public void ResetTxtsCar(){
        cbClienteCar.setSelectedIndex(0);
        txtIDCar.setText("");
        txtMatriculaCar.setText("");
        txtMarcaCar.setText("");
        txtModeloCar.setText("");
        txtFechaCar.setText("");
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelPrincipal = new javax.swing.JTabbedPane();
        PanelLg = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNombre_lg = new javax.swing.JTextField();
        btnLogin = new javax.swing.JButton();
        txtPassword_lg = new javax.swing.JPasswordField();
        PanelUsuario = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtBuscar_us = new javax.swing.JTextField();
        txtNombre_us = new javax.swing.JTextField();
        txtAP_us = new javax.swing.JTextField();
        txtAM_us = new javax.swing.JTextField();
        txtDireccion_us = new javax.swing.JTextField();
        cbPerfil_us = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtPassword_us = new javax.swing.JPasswordField();
        btnBuscar_us = new javax.swing.JButton();
        btnNuevo_us = new javax.swing.JButton();
        btnSalvar_us = new javax.swing.JButton();
        btnCancelar_us = new javax.swing.JButton();
        btnEditar_us = new javax.swing.JButton();
        btnRemover_us = new javax.swing.JButton();
        txtID_us = new javax.swing.JTextField();
        txtTelefono_us = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtNombreUS_us = new javax.swing.JTextField();
        PanelCl = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txtBuscarIdCli = new javax.swing.JTextField();
        btnBuscarCli = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        cbCli = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txtIDCli = new javax.swing.JTextField();
        txtNombreCLi = new javax.swing.JTextField();
        txtAPCli = new javax.swing.JTextField();
        txtAMCli = new javax.swing.JTextField();
        btnNuevoCLi = new javax.swing.JButton();
        btnSalvarCli = new javax.swing.JButton();
        btnCancelarCLi = new javax.swing.JButton();
        btnEditarCli = new javax.swing.JButton();
        btnRemoverCLi = new javax.swing.JButton();
        PanelRep = new javax.swing.JPanel();
        PanelPiezas = new javax.swing.JPanel();
        PanelVe = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        cbClienteCar = new javax.swing.JComboBox<>();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        txtIDCar = new javax.swing.JTextField();
        txtMatriculaCar = new javax.swing.JTextField();
        txtMarcaCar = new javax.swing.JTextField();
        txtModeloCar = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtIDBuscarCar = new javax.swing.JTextField();
        btnBuscarCar = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        txtFechaCar = new javax.swing.JTextField();
        btnNuevoCar = new javax.swing.JButton();
        btnSalvarCar = new javax.swing.JButton();
        btnCancelarCar = new javax.swing.JButton();
        btnEditarCar = new javax.swing.JButton();
        btnRemoverCar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nombre");

        jLabel2.setText("Password");

        btnLogin.setText("login");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelLgLayout = new javax.swing.GroupLayout(PanelLg);
        PanelLg.setLayout(PanelLgLayout);
        PanelLgLayout.setHorizontalGroup(
            PanelLgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelLgLayout.createSequentialGroup()
                .addGroup(PanelLgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelLgLayout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addGroup(PanelLgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(PanelLgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombre_lg, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPassword_lg, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelLgLayout.createSequentialGroup()
                        .addGap(171, 171, 171)
                        .addComponent(btnLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(303, Short.MAX_VALUE))
        );
        PanelLgLayout.setVerticalGroup(
            PanelLgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelLgLayout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addGroup(PanelLgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNombre_lg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(PanelLgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtPassword_lg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnLogin)
                .addContainerGap(119, Short.MAX_VALUE))
        );

        PanelPrincipal.addTab("Login", PanelLg);

        jLabel3.setText("Usuario ID");

        jLabel4.setText("Nombre");

        jLabel5.setText("Apellido Paterno");

        jLabel6.setText("Apellido Materno");

        jLabel7.setText("Direccion");

        jLabel8.setText("Perfil");

        jLabel9.setText("ID buscar");

        cbPerfil_us.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Admin\t", "Encargado", "Mecanico" }));

        jLabel10.setText("Telefono");

        jLabel12.setText("Password");

        btnBuscar_us.setText("Buscar");
        btnBuscar_us.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscar_usActionPerformed(evt);
            }
        });

        btnNuevo_us.setText("Nuevo");
        btnNuevo_us.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevo_usActionPerformed(evt);
            }
        });

        btnSalvar_us.setText("Salvar");
        btnSalvar_us.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvar_usActionPerformed(evt);
            }
        });

        btnCancelar_us.setText("Cancelar");
        btnCancelar_us.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelar_usActionPerformed(evt);
            }
        });

        btnEditar_us.setText("Editar");
        btnEditar_us.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditar_usActionPerformed(evt);
            }
        });

        btnRemover_us.setText("Remover");
        btnRemover_us.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemover_usActionPerformed(evt);
            }
        });

        txtID_us.setEditable(false);

        txtTelefono_us.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefono_usActionPerformed(evt);
            }
        });

        jLabel11.setText("Nombre Usuario");

        javax.swing.GroupLayout PanelUsuarioLayout = new javax.swing.GroupLayout(PanelUsuario);
        PanelUsuario.setLayout(PanelUsuarioLayout);
        PanelUsuarioLayout.setHorizontalGroup(
            PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelUsuarioLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtBuscar_us, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBuscar_us)
                .addContainerGap())
            .addGroup(PanelUsuarioLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addComponent(btnNuevo_us)
                        .addGap(18, 18, 18)
                        .addComponent(btnSalvar_us)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelar_us))
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(txtAM_us, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(txtAP_us, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelUsuarioLayout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtID_us, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelUsuarioLayout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addGap(59, 59, 59)
                            .addComponent(txtNombre_us, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(PanelUsuarioLayout.createSequentialGroup()
                            .addComponent(jLabel8)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbPerfil_us, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelUsuarioLayout.createSequentialGroup()
                            .addComponent(jLabel7)
                            .addGap(55, 55, 55)
                            .addComponent(txtDireccion_us, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addComponent(btnEditar_us)
                        .addGap(18, 18, 18)
                        .addComponent(btnRemover_us))
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel12))
                        .addGap(18, 18, 18)
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPassword_us, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTelefono_us, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtNombreUS_us)))
                .addContainerGap(89, Short.MAX_VALUE))
        );
        PanelUsuarioLayout.setVerticalGroup(
            PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelUsuarioLayout.createSequentialGroup()
                .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtID_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtNombre_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtAP_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)
                            .addComponent(txtNombreUS_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtBuscar_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar_us)
                            .addComponent(jLabel9))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(txtTelefono_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txtPassword_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelUsuarioLayout.createSequentialGroup()
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtAM_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtDireccion_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(cbPerfil_us, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevo_us)
                    .addComponent(btnSalvar_us)
                    .addComponent(btnCancelar_us)
                    .addComponent(btnEditar_us)
                    .addComponent(btnRemover_us))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        PanelPrincipal.addTab("Usuario", PanelUsuario);

        jLabel13.setText("Ingrese ID a buscar");

        btnBuscarCli.setText("Buscar");
        btnBuscarCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarCliActionPerformed(evt);
            }
        });

        jLabel14.setText("Seleccione ID usuario:");

        jLabel15.setText("Cliente ID");

        jLabel16.setText("Nombre:");

        jLabel17.setText("Apellido Paterno");

        jLabel18.setText("Apellido Materno");

        txtIDCli.setEditable(false);

        btnNuevoCLi.setText("Nuevo");
        btnNuevoCLi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoCLiActionPerformed(evt);
            }
        });

        btnSalvarCli.setText("Salvar");
        btnSalvarCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarCliActionPerformed(evt);
            }
        });

        btnCancelarCLi.setText("Cancelar");
        btnCancelarCLi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarCLiActionPerformed(evt);
            }
        });

        btnEditarCli.setText("Editar");
        btnEditarCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarCliActionPerformed(evt);
            }
        });

        btnRemoverCLi.setText("Remover");
        btnRemoverCLi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverCLiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelClLayout = new javax.swing.GroupLayout(PanelCl);
        PanelCl.setLayout(PanelClLayout);
        PanelClLayout.setHorizontalGroup(
            PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClLayout.createSequentialGroup()
                .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelClLayout.createSequentialGroup()
                        .addGap(191, 191, 191)
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addComponent(txtBuscarIdCli, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscarCli))
                    .addGroup(PanelClLayout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel15)
                            .addComponent(jLabel14)
                            .addComponent(jLabel16)
                            .addComponent(jLabel17)
                            .addComponent(jLabel18))
                        .addGap(18, 18, 18)
                        .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbCli, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(txtAMCli, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                                .addComponent(txtAPCli, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtNombreCLi, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtIDCli, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelClLayout.createSequentialGroup()
                .addGap(0, 70, Short.MAX_VALUE)
                .addComponent(btnNuevoCLi)
                .addGap(18, 18, 18)
                .addComponent(btnSalvarCli)
                .addGap(18, 18, 18)
                .addComponent(btnCancelarCLi)
                .addGap(18, 18, 18)
                .addComponent(btnEditarCli)
                .addGap(18, 18, 18)
                .addComponent(btnRemoverCLi)
                .addGap(66, 66, 66))
        );
        PanelClLayout.setVerticalGroup(
            PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelClLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtBuscarIdCli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarCli))
                .addGap(18, 18, 18)
                .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(cbCli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(txtIDCli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txtNombreCLi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txtAPCli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(txtAMCli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelClLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevoCLi)
                    .addComponent(btnSalvarCli)
                    .addComponent(btnCancelarCLi)
                    .addComponent(btnEditarCli)
                    .addComponent(btnRemoverCLi))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        PanelPrincipal.addTab("Clientes", PanelCl);

        javax.swing.GroupLayout PanelRepLayout = new javax.swing.GroupLayout(PanelRep);
        PanelRep.setLayout(PanelRepLayout);
        PanelRepLayout.setHorizontalGroup(
            PanelRepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 571, Short.MAX_VALUE)
        );
        PanelRepLayout.setVerticalGroup(
            PanelRepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 338, Short.MAX_VALUE)
        );

        PanelPrincipal.addTab("Reparaciones", PanelRep);

        javax.swing.GroupLayout PanelPiezasLayout = new javax.swing.GroupLayout(PanelPiezas);
        PanelPiezas.setLayout(PanelPiezasLayout);
        PanelPiezasLayout.setHorizontalGroup(
            PanelPiezasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 571, Short.MAX_VALUE)
        );
        PanelPiezasLayout.setVerticalGroup(
            PanelPiezasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 338, Short.MAX_VALUE)
        );

        PanelPrincipal.addTab("Piezas", PanelPiezas);

        jLabel19.setText("Seleccione Cliente");

        jLabel20.setText("Vehiculo ID");

        jLabel21.setText("Matricula");

        jLabel22.setText("Marca");

        jLabel23.setText("Modelo");

        txtIDCar.setEditable(false);

        jLabel24.setText("Ingrese ID a buscar");

        btnBuscarCar.setText("Buscar");
        btnBuscarCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarCarActionPerformed(evt);
            }
        });

        jLabel25.setText("Fecha");

        btnNuevoCar.setText("Nuevo");
        btnNuevoCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoCarActionPerformed(evt);
            }
        });

        btnSalvarCar.setText("Salvar");
        btnSalvarCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarCarActionPerformed(evt);
            }
        });

        btnCancelarCar.setText("Cancelar");
        btnCancelarCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarCarActionPerformed(evt);
            }
        });

        btnEditarCar.setText("Editar");
        btnEditarCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarCarActionPerformed(evt);
            }
        });

        btnRemoverCar.setText("Remover");
        btnRemoverCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverCarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelVeLayout = new javax.swing.GroupLayout(PanelVe);
        PanelVe.setLayout(PanelVeLayout);
        PanelVeLayout.setHorizontalGroup(
            PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelVeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelVeLayout.createSequentialGroup()
                        .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel23)
                            .addComponent(jLabel22)
                            .addComponent(jLabel21)
                            .addComponent(jLabel20)
                            .addComponent(jLabel19))
                        .addGap(18, 18, 18)
                        .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelVeLayout.createSequentialGroup()
                                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(PanelVeLayout.createSequentialGroup()
                                        .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(txtMatriculaCar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                                            .addComponent(txtMarcaCar, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(PanelVeLayout.createSequentialGroup()
                                        .addComponent(txtIDCar, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                                        .addGap(37, 37, 37)))
                                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(PanelVeLayout.createSequentialGroup()
                                        .addGap(84, 84, 84)
                                        .addComponent(jLabel25))
                                    .addComponent(jLabel24, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(PanelVeLayout.createSequentialGroup()
                                        .addComponent(txtIDBuscarCar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnBuscarCar))
                                    .addComponent(txtFechaCar, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(31, 31, 31))
                            .addGroup(PanelVeLayout.createSequentialGroup()
                                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtModeloCar, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbClienteCar, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(PanelVeLayout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addComponent(btnNuevoCar)
                        .addGap(18, 18, 18)
                        .addComponent(btnSalvarCar)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelarCar)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditarCar)
                        .addGap(18, 18, 18)
                        .addComponent(btnRemoverCar)
                        .addGap(35, 35, 35))))
        );
        PanelVeLayout.setVerticalGroup(
            PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelVeLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(cbClienteCar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelVeLayout.createSequentialGroup()
                        .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(txtIDCar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(txtMatriculaCar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelVeLayout.createSequentialGroup()
                        .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(txtIDBuscarCar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscarCar))
                        .addGap(18, 18, 18)
                        .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(txtFechaCar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(txtMarcaCar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(txtModeloCar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addGroup(PanelVeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevoCar)
                    .addComponent(btnSalvarCar)
                    .addComponent(btnCancelarCar)
                    .addComponent(btnEditarCar)
                    .addComponent(btnRemoverCar))
                .addGap(41, 41, 41))
        );

        PanelPrincipal.addTab("Vehiculos", PanelVe);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelPrincipal)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelPrincipal)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//Usuariuos
    private void btnSalvar_usActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvar_usActionPerformed
            us = new Usuario();
            us.setNombreUs(txtNombreUS_us.getText());
            if(!"".equals(BuscarUserString(txtNombreUS_us.getText()))){
                System.out.println("Nombre repetido");
            }else {
                contadorUs = BuscarIdUser();
                contadorUs++;
                us.setId_us(contadorUs);
                us.setNombre(txtNombre_us.getText());
                us.setAm(txtAM_us.getText());
                us.setAp(txtAP_us.getText());
                us.setDirec(txtDireccion_us.getText());
                us.setPerfil((String) cbPerfil_us.getSelectedItem());
                us.setNombreUs(txtNombreUS_us.getText());
                us.setTelefono(Integer.parseInt(txtTelefono_us.getText()));
                us.setPassword(txtPassword_us.getText());
                EscribirArchivoUS(us);
                cbCli.addItem(us.getNombreUs());
            }
            
    }//GEN-LAST:event_btnSalvar_usActionPerformed

    private void btnBuscar_usActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscar_usActionPerformed
        us = new Usuario();
        us.setId_us(Integer.parseInt(txtBuscar_us.getText()));
        us = leerArchivo(us);
        if(String.valueOf(us.getId_us()).equals(txtBuscar_us.getText())){
            DeshabilitarBtnUs();
            HabilitartxtUs();
            btnEditar_us.setEnabled(true);
            btnRemover_us.setEnabled(true);
            txtID_us.setText(String.valueOf(us.getId_us()));
            txtNombre_us.setText(us.getNombre());
            txtAP_us.setText(us.getAp());
            txtAM_us.setText(us.getAm());
            txtDireccion_us.setText(us.getDirec());
            cbPerfil_us.setSelectedItem(us.getPerfil());
            txtNombreUS_us.setText(us.getNombreUs());
            txtTelefono_us.setText(String.valueOf(us.getTelefono()));
            txtPassword_us.setText(us.getPassword()); 
        }else{
            JOptionPane.showMessageDialog(null,"Usuario no encontrado");
        }
        
    }//GEN-LAST:event_btnBuscar_usActionPerformed

    private void txtTelefono_usActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefono_usActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefono_usActionPerformed

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
       us = new Usuario();
       us.setNombreUs(txtNombre_lg.getText());
       us = BuscarUser(us);
       if(!"".equals(us.getNombreUs()) && txtPassword_lg.getText().equals(us.getPassword())){
            switch (us.getPerfil()) {
               case "Admin":
                   PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelLg),false);
                   HabilitarPaneles();
                   DeshabilitarBtnUs();
                   DeshabilitartxtUs();
                   DesabilitarBtnCli();
                   DesablilitartxtCli();
                   DesabilitartxtCar();
                   DesabilitarbtnCar();
                   JOptionPane.showMessageDialog(null, "Bienvenido "+ us.getNombreUs());
                   break;
               case "Encargado":
                   PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelCl),true);
                   PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelVe),true);
                   DesabilitarBtnCli();
                   DesablilitartxtCli();
                   DesabilitartxtCar();
                   DesabilitarbtnCar();
                   JOptionPane.showMessageDialog(null, "Bienvenido "+ us.getNombreUs());
                   break;
               case "Mecanico":
                   PanelPrincipal.setEnabledAt(PanelPrincipal.indexOfComponent(PanelRep),true);
                   JOptionPane.showMessageDialog(null, "Bienvenido "+ us.getNombreUs());
                   break;
               default:
                   JOptionPane.showMessageDialog(null, "Perfil no encotnrado");
                   break;
           }
       }
       else{
           JOptionPane.showMessageDialog(null,"Usuario o contraseña no encontrad@");
       }
    }//GEN-LAST:event_btnLoginActionPerformed

    private void btnNuevo_usActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevo_usActionPerformed
        ResetTxtUs();
        HabilitartxtUs();
        DeshabilitarBtnUs();
        btnSalvar_us.setEnabled(true);
        btnCancelar_us.setEnabled(true);
    }//GEN-LAST:event_btnNuevo_usActionPerformed

    private void btnCancelar_usActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelar_usActionPerformed
        ResetTxtUs();
        DeshabilitarBtnUs();
        DeshabilitartxtUs();
    }//GEN-LAST:event_btnCancelar_usActionPerformed

    private void btnEditar_usActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditar_usActionPerformed
        us = new Usuario();
        int idTemp=0;
        us.setId_us(Integer.parseInt(txtID_us.getText()));
        us = leerArchivo(us);
        idTemp = us.getId_us();
        borrarDatoArchivo(us);
        sobreEscribir();
        us.setId_us(idTemp);
        us.setNombre(txtNombre_us.getText());
        us.setAm(txtAM_us.getText());
        us.setAp(txtAP_us.getText());
        us.setDirec(txtDireccion_us.getText());
        us.setPerfil((String) cbPerfil_us.getSelectedItem());
        us.setNombreUs(txtNombreUS_us.getText());
        us.setTelefono(Integer.parseInt(txtTelefono_us.getText()));
        us.setPassword(txtPassword_us.getText());
        EscribirArchivoUS(us);
    }//GEN-LAST:event_btnEditar_usActionPerformed

    private void btnRemover_usActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemover_usActionPerformed
        us = new Usuario();
        us.setId_us(Integer.parseInt(txtBuscar_us.getText()));
        us = leerArchivo(us);
        if(us != null){
            borrarDatoArchivo(us);
            sobreEscribir();
            ResetTxtUs();
        }else{
            JOptionPane.showMessageDialog(null,"Usuario no existente");
        }
    }//GEN-LAST:event_btnRemover_usActionPerformed
    
    //Clientes
    //Nuevo cli
    private void btnNuevoCLiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoCLiActionPerformed
        ResetCli();
        HabilitartxtCli();
        btnSalvarCli.setEnabled(true);
        btnCancelarCLi.setEnabled(true);
    }//GEN-LAST:event_btnNuevoCLiActionPerformed
    //Cancelar cli
    private void btnCancelarCLiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarCLiActionPerformed
       ResetCli();
       DesabilitarBtnCli();
       DesablilitartxtCli();
    }//GEN-LAST:event_btnCancelarCLiActionPerformed
    //Salvar cli
    private void btnSalvarCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarCliActionPerformed
        us = new Usuario();
        cli = new Cliente();
        
        us.setNombreUs((String) cbCli.getSelectedItem());
        us = BuscarnameUs(us);
        cli.setIDUsuario(us.getId_us());
        contadorCli = SacarUltimoIdCli() + 1;
        cli.setIDcliente(contadorCli);
        cli.setNombreCliente(txtNombreCLi.getText());
        cli.setApCleinte(txtAPCli.getText());
        cli.setAmCliente(txtAMCli.getText());
        EscribirArchivoCli(cli);
        cbClienteCar.addItem(cli.getNombreCliente());
        ResetCli();
        DesabilitarBtnCli();
    }//GEN-LAST:event_btnSalvarCliActionPerformed
    //Buscar Cli
    private void btnBuscarCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarCliActionPerformed
        cli = new Cliente();
        us = new Usuario();
        
        cli.setIDcliente(Integer.parseInt(txtBuscarIdCli.getText()));
        cli = leerArchivoCli(cli);
        if(String.valueOf(cli.getIDcliente()).equals(txtBuscarIdCli.getText())){
            DesabilitarBtnCli();
            HabilitartxtCli();
            btnEditarCli.setEnabled(true);
            btnRemoverCLi.setEnabled(true);
            us.setId_us(cli.getIDUsuario());
            us = leerArchivo(us);
            cbCli.setSelectedItem(us.getNombreUs());
            txtIDCli.setText(String.valueOf(cli.getIDcliente()));
            txtNombreCLi.setText(cli.getNombreCliente());
            txtAPCli.setText(cli.getApCleinte());
            txtAMCli.setText(cli.getAmCliente());
        }else{
            JOptionPane.showMessageDialog(null,"Cliente no encontrado...");
        }
        
    }//GEN-LAST:event_btnBuscarCliActionPerformed

    private void btnRemoverCLiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverCLiActionPerformed
        cli = new Cliente();
        cli.setIDcliente(Integer.parseInt(txtIDCli.getText()));
        cli = leerArchivoCli(cli);
        if(cli != null){
            borrarCliente(cli);
            sobreEscribirCli();
            ResetTxtUs();
        }else{
            JOptionPane.showMessageDialog(null,"Usuario no existente");
        }
    }//GEN-LAST:event_btnRemoverCLiActionPerformed
    //Editar cli
    private void btnEditarCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarCliActionPerformed
        cli = new Cliente();
        us = new Usuario();
        cli.setIDcliente(Integer.parseInt(txtIDCli.getText()));
        cli = leerArchivoCli(cli);
        if(cli != null){
            borrarCliente(cli);
            sobreEscribirCli();
            us.setNombreUs((String) cbCli.getSelectedItem());
            us = BuscarnameUs(us);
            cli.setIDUsuario(us.getId_us());
            contadorCli = SacarUltimoIdCli() + 1;
            cli.setIDcliente(contadorCli);
            cli.setNombreCliente(txtNombreCLi.getText());
            cli.setApCleinte(txtAPCli.getText());
            cli.setAmCliente(txtAMCli.getText());
            EscribirArchivoCli(cli);
            ResetCli();
        }else{
            JOptionPane.showMessageDialog(null,"Cliente no existente");
        }
        
    }//GEN-LAST:event_btnEditarCliActionPerformed
    
    //AUTOS
    //Guardar autos
    private void btnNuevoCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoCarActionPerformed
        ResetTxtsCar();
        HabilitartxtCar();
        btnSalvarCar.setEnabled(true);
        btnCancelarCar.setEnabled(true);
    }//GEN-LAST:event_btnNuevoCarActionPerformed
    //Cancelar car
    private void btnCancelarCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarCarActionPerformed
        ResetTxtsCar();
        DesabilitarbtnCar();
        DesabilitartxtCar();
    }//GEN-LAST:event_btnCancelarCarActionPerformed

    private void btnSalvarCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarCarActionPerformed
        car = new Vehiculo();
        
        car.setClienteV(cbClienteCar.getSelectedItem().toString());
        contadorCar = SacarUltimoIdCar()+1;
        car.setIdVcar(contadorCar);
        car.setMatriculaCar(txtMatriculaCar.getText());
        car.setMarcaCar(txtMarcaCar.getText());
        car.setModeloCar(txtModeloCar.getText());
        car.setFecha(txtFechaCar.getText());
        EscribirArchivoCar(car);
        ResetTxtsCar();
    }//GEN-LAST:event_btnSalvarCarActionPerformed

    private void btnBuscarCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarCarActionPerformed
        car = new Vehiculo();
        
        car.setIdVcar(Integer.parseInt(txtIDBuscarCar.getText()));
        car = leerArchivoCar(car);
        if(String.valueOf(car.getIdVcar()).equals(txtIDBuscarCar.getText())){
            DesabilitarbtnCar();
            HabilitartxtCar();
            btnEditarCar.setEnabled(true);
            btnRemoverCar.setEnabled(true);
            cbClienteCar.setSelectedItem(car.getClienteV());
            txtIDCar.setText(String.valueOf(car.getIdVcar()));
            txtMatriculaCar.setText(car.getMatriculaCar());
            txtMarcaCar.setText(car.getMarcaCar());
            txtModeloCar.setText(car.getModeloCar());
            txtFechaCar.setText(car.getFecha());
        }else{
            JOptionPane.showMessageDialog(null,"Vehiculo no econtrado...");
        }
        
    }//GEN-LAST:event_btnBuscarCarActionPerformed
    //Borrar auto
    private void btnRemoverCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverCarActionPerformed
        car = new Vehiculo();
        car.setIdVcar(Integer.parseInt(txtIDCar.getText()));
        car = leerArchivoCar(car);
        if(car != null){
            borrarAuto(car);
            sobreEscribirCar();
            ResetTxtsCar();
        }else{
            JOptionPane.showMessageDialog(null,"Vehiculo no existente");
        }
    }//GEN-LAST:event_btnRemoverCarActionPerformed
    //Editar auto
    private void btnEditarCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarCarActionPerformed
        car = new Vehiculo();
        int idRemp;
        car.setIdVcar(Integer.parseInt(txtIDCar.getText()));
        car = leerArchivoCar(car);
        idRemp = car.getIdVcar();
        if(car != null){
            borrarAuto(car);
            sobreEscribirCar();
            car.setClienteV(cbClienteCar.getSelectedItem().toString());
            car.setIdVcar(idRemp);
            car.setMatriculaCar(txtMatriculaCar.getText());
            car.setMarcaCar(txtMarcaCar.getText());
            car.setModeloCar(txtModeloCar.getText());
            car.setFecha(txtFechaCar.getText());
            EscribirArchivoCar(car);
            ResetTxtsCar();
        }else{
            JOptionPane.showMessageDialog(null,"Vehiculo no existente");
        }
        
    }//GEN-LAST:event_btnEditarCarActionPerformed
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelCl;
    private javax.swing.JPanel PanelLg;
    private javax.swing.JPanel PanelPiezas;
    private javax.swing.JTabbedPane PanelPrincipal;
    private javax.swing.JPanel PanelRep;
    private javax.swing.JPanel PanelUsuario;
    private javax.swing.JPanel PanelVe;
    private javax.swing.JButton btnBuscarCar;
    private javax.swing.JButton btnBuscarCli;
    private javax.swing.JButton btnBuscar_us;
    private javax.swing.JButton btnCancelarCLi;
    private javax.swing.JButton btnCancelarCar;
    private javax.swing.JButton btnCancelar_us;
    private javax.swing.JButton btnEditarCar;
    private javax.swing.JButton btnEditarCli;
    private javax.swing.JButton btnEditar_us;
    private javax.swing.JButton btnLogin;
    private javax.swing.JButton btnNuevoCLi;
    private javax.swing.JButton btnNuevoCar;
    private javax.swing.JButton btnNuevo_us;
    private javax.swing.JButton btnRemoverCLi;
    private javax.swing.JButton btnRemoverCar;
    private javax.swing.JButton btnRemover_us;
    private javax.swing.JButton btnSalvarCar;
    private javax.swing.JButton btnSalvarCli;
    private javax.swing.JButton btnSalvar_us;
    private javax.swing.JComboBox<String> cbCli;
    private javax.swing.JComboBox<String> cbClienteCar;
    private javax.swing.JComboBox<String> cbPerfil_us;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txtAMCli;
    private javax.swing.JTextField txtAM_us;
    private javax.swing.JTextField txtAPCli;
    private javax.swing.JTextField txtAP_us;
    private javax.swing.JTextField txtBuscarIdCli;
    private javax.swing.JTextField txtBuscar_us;
    private javax.swing.JTextField txtDireccion_us;
    private javax.swing.JTextField txtFechaCar;
    private javax.swing.JTextField txtIDBuscarCar;
    private javax.swing.JTextField txtIDCar;
    private javax.swing.JTextField txtIDCli;
    private javax.swing.JTextField txtID_us;
    private javax.swing.JTextField txtMarcaCar;
    private javax.swing.JTextField txtMatriculaCar;
    private javax.swing.JTextField txtModeloCar;
    private javax.swing.JTextField txtNombreCLi;
    private javax.swing.JTextField txtNombreUS_us;
    private javax.swing.JTextField txtNombre_lg;
    private javax.swing.JTextField txtNombre_us;
    private javax.swing.JPasswordField txtPassword_lg;
    private javax.swing.JPasswordField txtPassword_us;
    private javax.swing.JTextField txtTelefono_us;
    // End of variables declaration//GEN-END:variables
}
