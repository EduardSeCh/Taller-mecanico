
package org.tallerMecanico;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import jdk.jfr.events.FileReadEvent;

public class AccesoDatos {
    private static String urlUs= "Usuarios.txt";
    private static String urlCli = "Clientes.txt";
    private static String urlCar = "Vehiculos.txt";
    private static  ArrayList<String> listNameUs;
    private static  ArrayList<String> listNameCli;
    public AccesoDatos() {
        
    }
     //Usuarios 
    public static void EscribirArchivoUS(Usuario us){
        File nuevoArchivo = new File(urlUs);
        
        try (PrintWriter salida = new PrintWriter(new FileWriter(nuevoArchivo,true))) {
            salida.println(String.valueOf(us.getId_us()));
            salida.println(us.getNombre());
            salida.println(us.getAp());
            salida.println(us.getAm());
            salida.println(us.getDirec());
            salida.println(us.getPerfil());
            salida.println(us.getNombreUs());
            salida.println(String.valueOf(us.getTelefono()));
            salida.println(us.getPassword());
        System.out.println("Archivo creado");
        }catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
    }   
    
    public static void BuscarRoot(Usuario us){
        File archivo = new File(urlUs);
        String idRemove = String.valueOf(us.getId_us());
        try {
            BufferedReader entrada = new BufferedReader(new FileReader(archivo));
            String currentLine;

            if((currentLine = entrada.readLine()) != null) {                        
                if(currentLine.trim().equals(idRemove)){ 
                    System.out.println("Root Encontrado"); 
                }
            }
            else{
                EscribirArchivoUS(us);
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
    }
    //Sacar todos los nameUs
    public static ArrayList SacarNameUs(){
        listNameUs = new ArrayList<>();
        int aux=0;
        File inputFile = new File(urlUs);
        try {
            int id = 0,tel;
            String name,ap,am,address,perfil,nameus,pass;
            Scanner entrada = new Scanner(inputFile);
            while(entrada.hasNextLine()){
                id = Integer.parseInt(entrada.nextLine());
                name = entrada.nextLine();
                ap = entrada.nextLine();
                am = entrada.nextLine();                
                address = entrada.nextLine();
                perfil = entrada.nextLine();
                nameus = entrada.nextLine();
                tel = Integer.parseInt(entrada.nextLine());
                pass = entrada.nextLine();
                listNameUs.add(nameus);
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
        return listNameUs;
        
    }
    
    public static Usuario leerArchivo(Usuario us){
        File archivo = new File(urlUs);
        try {
            int id = 0,tel;
            String name,ap,am,address,perfil,nameus,pass;
            Scanner entrada = new Scanner(archivo);
            while(entrada.hasNextLine()){
                id = Integer.parseInt(entrada.nextLine());
                name = entrada.nextLine();
                ap = entrada.nextLine();
                am = entrada.nextLine();                
                address = entrada.nextLine();
                perfil = entrada.nextLine();
                nameus = entrada.nextLine();
                tel = Integer.parseInt(entrada.nextLine());
                pass = entrada.nextLine();
                if(id == us.getId_us()){
                    us.setId_us(id);
                    us.setNombre(name);
                    us.setAp(ap);
                    us.setAm(am);
                    us.setDirec(address);
                    us.setPerfil(perfil);
                    us.setNombreUs(nameus);
                    us.setTelefono(tel);
                    us.setPassword(pass);
                    break;
                }
                else {
                    us.setId_us(0);
                }
            }
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
            System.out.println("Archivo Leido");
        return us;
    }
    
    //Buscar nameUs return us
    public static Usuario BuscarnameUs(Usuario us){
        File archivo = new File(urlUs);
        try {
            BufferedReader entrada = new BufferedReader(new FileReader(archivo));
            //Leer datos a archivo
            int id = 0,tel;
            String name,ap,am,address,perfil,nameus,pass;
            while(true){
                id = Integer.parseInt(entrada.readLine());
                name = entrada.readLine();
                ap = entrada.readLine();
                am = entrada.readLine();                
                address = entrada.readLine();
                perfil = entrada.readLine();
                nameus = entrada.readLine();
                tel = Integer.parseInt(entrada.readLine());
                pass = entrada.readLine();
                if(nameus.equals(us.getNombreUs())){
                    us.setId_us(id);
                    us.setNombre(name);
                    us.setAp(ap);
                    us.setAm(am);
                    us.setDirec(address);
                    us.setPerfil(perfil);
                    us.setNombreUs(nameus);
                    us.setTelefono(tel);
                    us.setPassword(pass);
                    break;
                }
            }
            entrada.close();
            System.out.println("Archivo Leido");
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
        return us;
    }
    //Buscar id
    public static int BuscarIdUser(){
        int aux=0;
        File inputFile = new File(urlUs);
        try {
            int id = 0,tel;
            String name,ap,am,address,perfil,nameus,pass;
            Scanner entrada = new Scanner(inputFile);
            while(entrada.hasNextLine()){
                id = Integer.parseInt(entrada.nextLine());
                name = entrada.nextLine();
                ap = entrada.nextLine();
                am = entrada.nextLine();                
                address = entrada.nextLine();
                perfil = entrada.nextLine();
                nameus = entrada.nextLine();
                tel = Integer.parseInt(entrada.nextLine());
                pass = entrada.nextLine();
            }
            aux=id;
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
        return aux;
    }
    
    //Buscar user String
    public static String BuscarUserString(String nameUS){
        String nameSearch = "";
        File inputFile = new File(urlUs);
        try {
          BufferedReader reader = new BufferedReader(new FileReader(inputFile));

        String currentLine;

        while((currentLine = reader.readLine()) != null) { 
            if(currentLine.trim().equals(nameUS)){ 
                nameSearch = nameUS;
                break;
            }
           
        }       
        reader.close();
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }
        return nameSearch;
    }
    
    //BuscarUsuario
    public static Usuario BuscarUser(Usuario us){
        String nameSearch = us.getNombreUs();
        File inputFile = new File(urlUs);
        try {
            int id,tel;
            String name,ap,am,address,perfil,nameus,pass;
            Scanner entrada = new Scanner(inputFile);
            while(entrada.hasNextLine()){
                id = Integer.parseInt(entrada.nextLine());
                name = entrada.nextLine();
                ap = entrada.nextLine();
                am = entrada.nextLine();                
                address = entrada.nextLine();
                perfil = entrada.nextLine();
                nameus = entrada.nextLine();
                tel = Integer.parseInt(entrada.nextLine());
                pass = entrada.nextLine();
                if(nameus.equals(nameSearch)){
                    us.setId_us(id);
                    us.setNombre(name);
                    us.setAp(ap);
                    us.setAm(am);
                    us.setDirec(address);
                    us.setPerfil(perfil);
                    us.setNombreUs(nameus);
                    us.setTelefono(tel);
                    us.setPassword(pass);
                    break;
                }
                else{
                    us.setNombreUs("");
                }
            }
            
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
        return us;
    }
    //Boorar dato
    public static void borrarDatoArchivo(Usuario us){
        String idRemove = String.valueOf(us.getId_us());
        String nameRemove = us.getNombre();
        String ApRemove = us.getAp();
        String AmRemove = us.getAm();
        String adressRemove = us.getDirec();
        String perfilRemove = us.getPerfil();
        String NameUsRem = us.getNombreUs();
        String telRem = String.valueOf(us.getTelefono());
        String passRem = us.getPassword();
        File inputFile = new File(urlUs);
        File outputFile = new File("Usuarios_aux.txt");

        try {
          BufferedReader reader = new BufferedReader(new FileReader(inputFile));
          BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

        String currentLine;

        while((currentLine = reader.readLine()) != null) { 
            if(currentLine.trim().equals(idRemove)){ 
                continue; 
            }
            if(currentLine.trim().equals(nameRemove)){ 
                continue; 
            }
            if(currentLine.trim().equals(ApRemove)){ 
                continue; 
            }
            if(currentLine.trim().equals(AmRemove)){ 
                continue; 
            }
            if(currentLine.trim().equals(adressRemove)){ 
                continue; 
            }
            if(currentLine.trim().equals(perfilRemove)){ 
                continue; 
            }
            if(currentLine.trim().equals(NameUsRem)){ 
                continue; 
            }
            if(currentLine.trim().equals(telRem)){ 
                continue; 
            }
            if(currentLine.trim().equals(passRem)){ 
                continue; 
            }
            writer.write(currentLine + System.getProperty("line.separator"));
        }       
        writer.close();
        reader.close();
        System.out.println("Usuario borrado");
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }
    }
    
    public static void sobreEscribir(){
        File archivonuevo = new File("Usuarios_aux.txt");
        File archivoOriginal = new File(urlUs);
        
        try {
          BufferedReader reader = new BufferedReader(new FileReader(archivonuevo));
          BufferedWriter writer = new BufferedWriter(new FileWriter(archivoOriginal));

        String currentLine;

        while((currentLine = reader.readLine()) != null) {                        
            writer.write(currentLine + System.getProperty("line.separator"));
        }       
        writer.close();
        reader.close();
            System.out.println("Archivo cambiado");
            
        
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }
    }
    
    //Clientes
    //
    public static void EscribirArchivoCli(Cliente cli){
        File nuevoArchivo = new File(urlCli);
        
        try (PrintWriter salida = new PrintWriter(new FileWriter(nuevoArchivo,true))) {
            salida.println(String.valueOf(cli.getIDUsuario()));
            salida.println(String.valueOf(cli.getIDcliente()));
            salida.println(cli.getNombreCliente());
            salida.println(cli.getApCleinte());
            salida.println(cli.getAmCliente());
        System.out.println("Archivo Clientes creado");
        }catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
    }
    //Buscar ultimo id cliente
    public static int SacarUltimoIdCli(){
        int aux=0;
        File inputFile = new File(urlCli);
        try {
            int idCli = 0,idUs=0;
            String name,ap,am;
            Scanner entrada = new Scanner(inputFile);
            while(entrada.hasNextLine()){
                idCli = Integer.parseInt(entrada.nextLine());
                idUs = Integer.parseInt(entrada.nextLine());
                name = entrada.nextLine();
                ap = entrada.nextLine();
                am = entrada.nextLine();                
            }
            aux=idUs;
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
        return aux;
    }
    
    //Leer archivo por id
    public static Cliente leerArchivoCli(Cliente cli){
        File archivo = new File(urlCli);
        try (Scanner entrada = new Scanner(archivo)) {
            int idUs = 0,idCLi=0;
            String name,ap,am;
            while(entrada.hasNextLine()){
                idUs = Integer.parseInt(entrada.nextLine());
                idCLi = Integer.parseInt(entrada.nextLine());
                name = entrada.nextLine();
                ap = entrada.nextLine();
                am = entrada.nextLine();                
                
                if(idCLi == cli.getIDcliente()){
                    cli.setIDUsuario(idUs);
                    cli.setIDcliente(idCLi);
                    cli.setNombreCliente(name);
                    cli.setApCleinte(ap);
                    cli.setAmCliente(am);
                    break;
                }
                else{
                    cli.setIDcliente(0);
                }
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
            System.out.println("Archivo Cliente Leido");
        return cli;
    }
    //Borar cliente
    public static void borrarCliente(Cliente cli){
        String idUsRemove = String.valueOf(cli.getIDUsuario());
        String idClimove = String.valueOf(cli.getIDcliente());
        String nameRemove = cli.getNombreCliente();
        String ApRemove = cli.getApCleinte();
        String AmRemove = cli.getAmCliente();
        
        File inputFile = new File(urlCli);
        File outputFile = new File("Clientes_aux.txt");

        try {
          BufferedReader reader = new BufferedReader(new FileReader(inputFile));
          BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
        String datosCli[];
        datosCli = new String[5];
        int i =0;
        String currentLine;

        while((currentLine = reader.readLine()) != null) { 
            datosCli[i] = currentLine;
            i++;
            if(i==5){
                if(datosCli[0].equals(idUsRemove) && datosCli[1].equals(idClimove)){
                    System.out.println("Cliente encontrado");
                } else {
                    for (int j = 0; j < i; j++) {
                        writer.write(datosCli[j] + System.getProperty("line.separator")); 
                    }
                }
                i=0;
            }
        }       
        writer.close();
        reader.close();
        System.out.println("Cliente borrado");
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }
    }
    //Sobreescribir cliente.txt
    public static void sobreEscribirCli(){
        File archivonuevo = new File("Clientes_aux.txt");
        File archivoOriginal = new File(urlCli);
        
        try {
          BufferedReader reader = new BufferedReader(new FileReader(archivonuevo));
          BufferedWriter writer = new BufferedWriter(new FileWriter(archivoOriginal));

        String currentLine;

        while((currentLine = reader.readLine()) != null) {  
            
            writer.write(currentLine + System.getProperty("line.separator"));
        }       
        writer.close();
        reader.close();
        System.out.println("Archivo Clientes cambiado");
            
        
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }
    }
    //Sacar todos los name clientes
    public static ArrayList SacarNameCli(){
        listNameCli = new ArrayList<>();
        int aux=0;
        File inputFile = new File(urlCli);
        try {
            int iDUs = 0,idCli;
            String name,ap,am;
            Scanner entrada = new Scanner(inputFile);
            while(entrada.hasNextLine()){
                iDUs = Integer.parseInt(entrada.nextLine());
                idCli = Integer.parseInt(entrada.nextLine());
                name = entrada.nextLine();
                ap = entrada.nextLine();
                am = entrada.nextLine();                
                
                listNameCli.add(name);
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
        return listNameCli;
        
    }
    
    //Car
    public static void EscribirArchivoCar(Vehiculo car){
        File nuevoArchivo = new File(urlCar);
        
        try (PrintWriter salida = new PrintWriter(new FileWriter(nuevoArchivo,true))) {
            salida.println(car.getClienteV());
            salida.println(String.valueOf(car.getIdVcar()));
            salida.println(car.getMatriculaCar());
            salida.println(car.getMarcaCar());
            salida.println(car.getModeloCar());
            salida.println(car.getFecha());
        System.out.println("Archivo Vehiculos creado");
        }catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
    }
    //Leer archivo por Car.id
    public static Vehiculo leerArchivoCar(Vehiculo car){
        File archivo = new File(urlCar);
        try {
            Scanner entrada = new Scanner(archivo);
            //Leer datos a archivo
            int idCar = 0;
            String clienteV,matricula,marca,modelo,fecha;
            while(entrada.hasNextLine()){
                clienteV = entrada.nextLine();
                idCar = Integer.parseInt(entrada.nextLine());
                matricula = entrada.nextLine();
                marca = entrada.nextLine();
                modelo = entrada.nextLine();                
                fecha = entrada.nextLine();
                if(idCar == car.getIdVcar()){
                    car.setClienteV(clienteV);
                    car.setIdVcar(idCar);
                    car.setMatriculaCar(matricula);
                    car.setMarcaCar(marca);
                    car.setModeloCar(modelo);
                    car.setFecha(fecha);
                    break;
                }else{
                    car.setIdVcar(0);
                }
            }
            entrada.close();
            System.out.println("Archivo Vehiculo Leido");
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
        return car;
    }
    //Borrar auto
    public static void borrarAuto(Vehiculo car){
        String idCar = String.valueOf(car.getIdVcar());
        String clienteCar = String.valueOf(car.getClienteV());
        File inputFile = new File(urlCar);
        File outputFile = new File("Vehiculos_aux.txt");

        try {
          BufferedReader reader = new BufferedReader(new FileReader(inputFile));
          BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
        String datosCar[];
        datosCar = new String[6];
        int i =0;
        String currentLine;

        while((currentLine = reader.readLine()) != null) { 
            datosCar[i] = currentLine;
            i++;
            if(i==6){
                if(datosCar[0].equals(clienteCar) && datosCar[1].equals(idCar)){
                    System.out.println("Auto encontrado");
                } else {
                    for (int j = 0; j < i; j++) {
                        writer.write(datosCar[j] + System.getProperty("line.separator")); 
                    }
                }
                i=0;
            }
        }       
        writer.close();
        reader.close();
        System.out.println("Auto borrado");
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }
    }
    //Sobreescribir autos.txt
    public static void sobreEscribirCar(){
        File archivonuevo = new File("Vehiculos_aux.txt");
        File archivoOriginal = new File(urlCar);
        
        try {
          BufferedReader reader = new BufferedReader(new FileReader(archivonuevo));
          BufferedWriter writer = new BufferedWriter(new FileWriter(archivoOriginal));

        String currentLine;
        while((currentLine = reader.readLine()) != null) {  
            
            writer.write(currentLine + System.getProperty("line.separator"));
        }       
        writer.close();
        reader.close();
        System.out.println("Archivo Vehiculos cambiado");
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }
    }
    
    //Buscar ultimo id car
    public static int SacarUltimoIdCar(){
        int aux=0;
        File inputFile = new File(urlCar);
        try {
            int idCar = 0;
            String clientCar,matricula,marca,modelo,fecha;
            Scanner entrada = new Scanner(inputFile);
            while(entrada.hasNextLine()){
                clientCar = (entrada.nextLine());
                idCar = Integer.parseInt(entrada.nextLine());
                matricula = entrada.nextLine();
                marca = entrada.nextLine();
                modelo = entrada.nextLine(); 
                fecha = entrada.nextLine();
            }
            aux=idCar;
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
        return aux;
    }
}
